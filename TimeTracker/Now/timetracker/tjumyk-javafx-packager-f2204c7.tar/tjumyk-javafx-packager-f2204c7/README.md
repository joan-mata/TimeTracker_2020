javafx-packager
===============

A GUI packaging tool to generate Single Runnable Jars for JavaFx2 programmes.

You can check this [Online Tool](http://tjumyk.github.io/javafx-packager/) *(You need Java & its browser plugin support)*

or download this project and run it locally.

![screenshot](https://github.com/tjumyk/javafx-packager/raw/master/dist/screenshot.png)
